#include <iostream>
#include <string.h>
#include<ctime>
#pragma disable(warning:4996)
void getNoOfDays(int);
using namespace std;

int main()
{
	char day[3], month[3], year[5];
	cout << "Please input the date in dd/mm/yyyy format:";
	cin.get(day, 3, '/');
	cin.ignore(100, '/');
	cin.get(month, 3, '/');
	cin.ignore(100, '/');
	cin.get(year, 5);
	int m = atoi(month);
	getNoOfDays(m);	
}

void getNoOfDays(int m)
{
	int no_of_days;
	string month;
	string months[] = { "January", "February", "March", "April", "May","June", "July", "August", "September", "October", "November", "December" };
	month=months[m - 1];

	if (m == 2)
	{
		no_of_days = 28;
	}
	else if (m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12)
		no_of_days = 31;
	else
		no_of_days = 30;

	cout << month << " has " << no_of_days << " days" << endl;
}