// Inheritance.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

class Base 
{
public:void foo()
	{
		cout << "foo base" << endl;
	}
	void foo(int x)
	{
		  cout << "foo int base" << endl;
	}
	void foo(float x)
	{
		cout << "foo float base" << endl;
	}
};

class Derived :public Base
{
public:using Base::foo; 
	  void foo(double x)
	  {
		  cout << "foo double derived" << endl;
	  }
	  void foo(float x)
	  {
		  Base::foo(10.2f);
		  cout << "foo float derived" << endl;
	  }
	  void bar()
	  {
			cout << "bar derived" << endl;
	  }
};

//int main()
//{
//	Derived d1;
//	//d1.foo();
//	/*d1.foo();
//	d1.foo(100);*/
//	d1.foo(3.66f);
//	return 0;
//}