// polymorphism.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

class Base
{
public:virtual void foo() 
	   { 
			cout << "foo base" << endl; 
	   }
};

class Derived :public Base
{
public:void foo()
	   {
			cout << "foo derived" << endl;
	   }
	  void bar()
	  {
		  cout << "bar derived" << endl;
	  }
	  //void operator=(Base& b) {}
};
//
//int main()
//{
//	Base b1, * bptr;
//	Derived d1, *dptr;
//	bptr = &b1;
//	bptr->foo();
//	bptr = &d1;
//	bptr->foo();
//	//bptr->bar();
//	static_cast<Derived*>(bptr)->foo();
//	//d1 = b1;
//	return 0;
//}