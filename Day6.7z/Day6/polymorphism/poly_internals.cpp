
#include <iostream>
using namespace std;

class Base
{
public:virtual void foo()
       {
	      cout << "foo base" << endl;
       }
	   void bar()
	   {
		  cout << "bar base" << endl;
	   }
};

class Derived :public Base
{
public:void foo()
	   {
			cout << "foo derived" << endl;
       }
	   void bar()
	   {
		  cout << "bar derived" << endl;
	   }
	  //void operator=(Base& b) {}
};

typedef void (*ptr)();

int main()
{
	Base b1;
	cout << "Address of VPTR:" << &b1 << endl;
	cout << "Address of VTABLE:" << (*(int*)&b1) << endl;
	ptr p1 = (ptr) * (int*) * (int*) &b1;
	p1();
	return 0;
}