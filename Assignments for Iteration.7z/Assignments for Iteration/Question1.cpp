#include <iostream>
#include <Windows.h>
using namespace std;

int main()
{
	for (int i = 0; i <= 255; i++)
	{
		printf("Character %c has the ASCII value of %d\n", i, i);
		if (i % 10 == 0)
			Sleep(1000);
	}
}