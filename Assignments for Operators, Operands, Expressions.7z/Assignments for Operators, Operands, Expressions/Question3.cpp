#include <iostream>
#include <string>
#include <math.h>
using namespace std;

void sum_of_digit(int num, int* res);

int main()
{

    int num, length;
    cout << "Enter a number:";
    cin >> num;
    length = to_string(num).length();
    int* res = (int*)malloc(sizeof(int) * length);
    if (length>4)
        cout << "Number should be less than 4 digit " << endl;
    else 
    {
        sum_of_digit( num, res);

        cout << "output:";
        for (int i = length; i > 0; i--)
        {
            cout << *(res + i);
            if (i > 1)
                cout << "+";
        }
    }
	return 0;

}
void sum_of_digit(int num, int* res)
{
    int rem, sum = 0, i = 0;

    while (num != 0)
    {
        rem = num % 10;
        *(res + i) = rem * pow(10, i++);

        num = num / 10;
    }

}