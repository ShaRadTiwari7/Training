#include <iostream>
using namespace std;

int main()
{
  
    cout << "Hello Wolrd" << endl;
    cout << "Hello Wolrd\n" << endl;
    cout << "Hello Wolrd\t" << endl;
    cout << "Hello Wolrd\b" << endl;
    cout << "Hello Wolrd\"" << endl; 
    return 0;	
}