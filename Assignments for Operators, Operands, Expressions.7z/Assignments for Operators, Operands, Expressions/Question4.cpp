#include <iostream>
using namespace std;

int main()
{
	int num1 = 1000, num2 = 2000;
	int sum = 0;
	sum = num1 + num2;
	cout << "The sum is " << sum;

	cout << "\nThe sum is " << num1 + num2;
	return 0;
}