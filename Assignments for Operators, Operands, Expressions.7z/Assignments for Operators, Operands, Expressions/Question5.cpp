#include <iostream>
#include <math.h>
using namespace std;

void swap_using_temp(int &num1, int &num2)
{
    int temp = num1;
    num1 = num2;
    num2 = temp;

}

void swap_without_using_temp(int &num1, int &num2)
{
    num1 = num1 + num2;
    num2 = num1 - num2;
    num1 = num1 - num2;

}

int main()
{
  
    int num1, num2;
    cin >> num1 >> num2;
    cout << "num1 and num2 before swaping" << endl;
    cout << num1 << " " << num2 << endl;
	
    swap_using_temp(num1, num2);
    cout << "num1 and num2 after swaping using temp variable" << endl;
    cout << num1 << " " << num2 << endl;
	
    swap_without_using_temp(num1, num2);
    cout << "num1 and num2 after swaping without using temp variable" << endl;
    cout << num1 << " " << num2 << endl;
    return 0;
}