
#include <iostream>
#include<vector>
#include<algorithm>
#include<array>
using namespace std;
//void show(int x)
//{
// cout << "using show" << x << endl;
//}
class employee
{
	string name;
	int empid;
public:employee() {}
	  employee(int id, string nm) :empid(id), name(nm) {}
	  void accept()
	  {
		  cout << "enter empid and name" << endl;
		  cin >> empid >> name;
	  }
	  void show()
	  {
		  cout << empid << " " << name << endl;
	  }
};
int main()
{
	vector<employee> v1(3);
	v1[0] = employee(100, "vijay");
	v1[1] = employee(200, "sharad");
	v1[2] = employee(300, "divy");
	v1.push_back(employee(400, "venu"));
	v1.push_back(employee(500, "akash"));
	v1.push_back(employee(600, "praveen"));
	cout << "eneter employee records" << endl;
	for (vector<employee>::iterator itr = v1.begin(); itr != v1.end(); ++itr)
		itr->accept();
	cout << "employee records are" << endl;
	for (vector<employee>::iterator itr = v1.begin(); itr != v1.end(); ++itr)
		itr->show();
	//array <string, 4> arr1 = { "divy","sharad","vijay","mohith" };
	////std::sort(arr1.begin(), arr1.end());
	//std::reverse(arr1.begin(), arr1.end());
	//for (int i = 0; i < arr1.size(); ++i)
	//{
	// cout << arr1[i] << endl;
	//}
	//vector<int> v1{ 10,20,30,40,50 };
	///* cout << v1.size() << endl;
	// cout << v1.capacity() << endl;*/
	//v1.push_back(60);
	//v1.push_back(70);
	//v1.push_back(80);
	///*cout << v1.size() << endl;
	//cout << v1.capacity() << endl;*/
	//for (int i = 0; i < v1.size(); ++i)
	//{
	// cout << v1[i] << " " << v1.at(i) << endl;
	// v1[0] = 1000;
	// v1[1] = 2000;
	//}
	//cout << "using iterators to display contents of vector" << endl;
	//for (vector<int>::iterator itr = v1.begin(); itr != v1.end(); ++itr)
	//{

	// cout << *itr << endl;
	//}

	//cout << "using constant iterators to display contents of vector" << endl;
	//for (vector<int>::const_iterator citr = v1.cbegin(); citr != v1.cend(); ++citr)
	// cout << *citr << endl;

	//cout << "using reverse iterators to display contents of vector" << endl;
	//for (vector<int>::reverse_iterator ritr = v1.rbegin(); ritr != v1.rend(); ++ritr)
	// cout << *ritr << endl;

	//vector<int>::iterator myitr = v1.begin();
	//cout << "first element of vector is" << *myitr << endl;
	//myitr = v1.end() - 1;
	//cout << "last element of vector is" << *myitr << endl;

	//for (auto i : v1)
	//{
	// if (i % 2 == 0)
	// cout << i <<endl;
	//}
	/* for_each(v1.begin(), v1.end(), show);
	v1.pop_back();
	v1.pop_back();
	v1.pop_back();
	v1.insert(v1.begin(), 99);
	v1.insert(v1.begin() + 2, 999);
	v1.erase(v1.begin(), v1.end() - 2);
	v1.erase(v1.begin());*/

	return 0;
}