// smart_pointers.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include<memory>
#include<crtdbg.h>
using namespace std;

class vehicle 
{
	   string name;
public:vehicle() { cout << "vehicle is created" << endl; }
	   vehicle(string);
	   vehicle start() { cout << name << "started" << endl; }
	   vehicle stop() { cout << name << "stopped" << endl; }
};
int main()
{
	//vehicle* myvehicle = new vehicle("audi");

	//myvehicle->start();
	//myvehicle->stop();
	//delete myvehicle;
	shared_ptr<vehicle> myvehicle{ new vehicle("audi") };
	myvehicle->start();
	{
		shared_ptr<vehicle>mynewvehicle = myvehicle;
		cout << myvehicle.use_count() << endl;
	}
	(*myvehicle).stop();

	/*
	{
	shared_ptr<int> ptr(new int);
	cin >> *ptr;
	cout << *ptr << " " << ptr.use_count() << endl;
	shared_ptr<int> newptr = ptr;
	cout << *newptr << endl;
	cout << newptr.use_count() << endl;
	unique_ptr<int>myuniq1{new int(100)};
	unique_ptr<int>myuniq2=move(myuniq1);
	cout << *myuniq2<< endl;
	}
	cout << "leaks" << _CrtDumpMemoryLeaks() << endl;*/
}