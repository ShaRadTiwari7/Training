#include <iostream>
#include "mystack.h"
#include "mystack.cpp"
using namespace std;

void menu(Mystack<const char*> &ss)
{
	int choice;
	int values;
	while (1)
	{
		cout << "Enter 1 to push" << endl;
		cout << "Enter 2 to pop" << endl;
		cout << "Enter 3 to display" << endl;
		cin >> choice;
		switch (choice)
		{
		case 1:cout << "Enter value to push:";
			cin >> values;
			ss.push(values);
			break;
		case 2:cout << "Enter value to pop:";
			cin >> values;
			ss.push(values);
			break;
		case 3:cout << "Elements in stack are:" << endl;
			ss.display();
			break;
			
		default:cout << "Invalid input" << endl;
			break;
		}

	}
}
int main()
{
	Mystack <string> s1;
	try
	{
		menu(s1);
	}
	catch (string s)
	{
		cout << s << endl;
	}
	s1.display();
	try
	{
		cout << "Poped element is " << s1.pop() << endl;
	}
	catch (string s)
	{
		cout << s << endl;
	}
	return 0;
}