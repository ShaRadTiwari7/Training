// templates.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <vector>
#include "Header.h"
using namespace std;

int main()
{
    show(10,"sachin");
    show("sachin",100);
    show(12, 45.67);
    show('A', 45.67f);
    //int x = 100, y = 200;
    //cout << x << " " << y << endl;
    //swap(x, y);
    //cout << x << " " << y << endl;
    //string name1 = "sachin1", name2 = "sehwag";
    //myswap(name1, name2);
    //cout << name1 << " " << name2 << endl;
    return 0;
}
