// Exception1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <setjmp.h>
#include <string>
using namespace std;

jmp_buf j;

class Demo
{
public:Demo() { cout << "ctor base called" << endl; }
	  ~Demo() {cout << "dest base called"<<endl; }
};

class Derived :public Demo
{
public:Derived() { cout << "ctor der called" << endl; }
	  ~Derived() { cout << "dest der called" << endl; }
};

float divide(int x, int y)
{
	int* ptr = new int(5);
	if (y == 0)
		throw 99;
		//longjmp(j, 1);
	if (y == -1)
		throw string("negative value");
	if (y == -2)
	{
		Derived d1;
		throw d1;
	}
	delete ptr;
	return static_cast<float>(x) / y;
}

int main()
{
	//if (setjmp(j) == 0)
	try
	{
		cout << divide(10, 3) << endl;
		//cout << divide(10, 0) << endl;
		//cout << divide(10, -1) << endl;
		cout << divide(10, -2) << endl;
	}
	//else
	catch(int)
	{
		cout << "Divide by zero has occured" << endl;
	}
	catch (string& s)
	{
		cout << s << endl;
	}
	catch (Demo dd)
	{
		cout << "catch block for base class" << endl;
	}
	catch (Derived dd)
	{
		cout << "catch block for derived class" << endl;
	}
	catch (...)
	{
		cout << "Universal catch" << endl;
	}
	return 0;
}