// singleton.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include<iostream>
using namespace std;

class singleton
{
private: int data;
	   static singleton* ptr;
	   singleton() {}
	   singleton(int data) :data(data) {}

public: static singleton* createsingleton(int value)
{
	    if (ptr == NULL)
	    {
	    	ptr = new singleton(value);
	    	return ptr;
	    }
	    else
	    	return ptr;
}
	    void showdata()
	    {
			cout << data << endl;
			cout << "address of the object" <<this<< endl;
	    }
};

singleton* singleton::ptr = NULL;

int main()
{
	singleton::createsingleton(1000)->showdata();
	singleton::createsingleton(2000)->showdata();
	singleton::createsingleton(3000)->showdata();
	return 0;
}