#include <iostream>
using namespace std;

typedef struct Node1
{
   int data;
   struct  Node1* leftlink;
   struct Node1* rightlink;
}Node;

Node* getNode()
{
    Node* temp = (Node*)malloc(sizeof(struct Node1));
    if (temp == NULL)
        cout << "Memory is not allocated!" << endl;
    temp->leftlink = NULL;
    temp->rightlink = NULL;
    return temp;
}

Node* InsertInBegin(Node* Head)
{
    Node* temp = getNode();
    cout << "Enter the data" << endl;
    cin >> temp->data;
    cout << temp->data << " is Inserted" << endl;
    if (Head == NULL)
    {
        Head = temp;
        return Head;
    }
    temp->leftlink = Head;
    Head->rightlink = temp; 
    return temp;
}

Node* InsertInEnd(Node* Head)
{
    Node* temp = getNode();
    Node* cur=Head;
    cout << "Enter the data" << endl;
    cin >> temp->data;
    cout << temp->data << " is Inserted" << endl;
    if (Head == NULL)
    {
        Head = temp;
        return Head;
    }
    while (cur->leftlink != NULL)
        cur = cur->leftlink;
    cur->leftlink = temp;
    temp->rightlink = cur;
    return Head;
}

Node* InsertInBetween(Node* Head)
{
    int pos,count;
    Node* temp = getNode();
    cout << "Enter the pos" << endl;
    cin >> pos;
    cout << "Enter the data" << endl;
    cin >> temp->data;
    cout << temp->data << " is Inserted" << endl;
    if (Head == NULL)
    {
        Head = temp;
        return Head;
    }
    Node* cur = Head;
    Node* prv = cur;
    for (count = 0;cur->leftlink != NULL;cur = cur->leftlink ,count++)
    {
        if (count+1 == pos)
        {
            prv->leftlink = temp;
            temp->rightlink = prv;
            cur->rightlink =  temp;
            temp->leftlink = cur;
            break;
        }
        prv = cur;
    }
    return Head;
}

Node* DeleteInBegin(Node* Head)
{
    if (Head == NULL)
        cout << "No Element in a list";
    if (Head->leftlink == NULL)
    {
        free(Head);
        return NULL;
    }
    Node* next;
    cout << Head->data << " is Deleted" << endl;
    (Head->leftlink)->rightlink = NULL;
    next = Head->leftlink;
    free(Head);
    return next;
}

Node* DeleteInEnd(Node* Head)
{
    if (Head == NULL)
        cout << "No Element in a list";
    if (Head->leftlink == NULL)
    {
        free(Head);
        return NULL;
    }
    Node* cur = Head;
    Node* prv = cur;
   
    while (cur->leftlink != NULL)
    {
        prv = cur;
        cur = cur->leftlink;
    }
    cout << cur->data << " is Deleted" << endl;
    prv->leftlink = NULL;
    cur->rightlink = NULL;
    free(cur);  
    return Head;
}

Node* DeleteInBetween(Node* Head)
{
    int pos,count;
    if (Head == NULL)
        cout << "No Element in a list";
    cout << "Enter the pos" << endl;
        cin >> pos;
    if (Head->leftlink == NULL)
    {
        free(Head);
        return NULL;
    }
    Node* cur = Head;
    Node* prv = cur;
    for (count = 0;cur->leftlink != NULL;cur = cur->leftlink,count++)
    {
        if (count+1 == pos)
        {
          
            prv->leftlink = cur->leftlink;
            cur->rightlink = prv;
            cout << cur->data << " is deleted" << endl;
            free(cur);
            break;
        }
        prv = cur;
    }
    return Head;
}

void display_list(Node* Head)
{
    if (Head == NULL)
    {
        cout << "No element in a list"<<endl;
        return;
    }
      
    if (Head->leftlink == NULL)
    {
        cout << Head->data << endl;
    }
    Node* cur = Head;
  

    while (cur != NULL)
    {
        cout << cur->data << "->";
        cur = cur->leftlink;
    }       
    cout << endl;
}

int main()
{
    Node* Head=NULL;
    int ch;
    while (1)
    {
        cout << "1.Insert at Begin\n2.Insert at End\n3.Delete at Begin\n4.Delete at End\n5.Insert Between\n6.Delete Between\n7.Print List\n8.Exit\n";
        cin >> ch;
        switch (ch)
        {
        case 1: Head = InsertInBegin(Head);
                break;
        case 2: Head = InsertInEnd(Head);
                break;
        case 3: Head = DeleteInBegin(Head);
                break;
        case 4: Head = DeleteInEnd(Head);
                break;
        case 5: Head = InsertInBetween(Head);
                break;
        case 6: Head = DeleteInBetween(Head);
                break;
        case 7: display_list(Head);
                break;
        default: exit(0);
        }
    }
}